package com.example.smartschedule;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.*;

public class MainActivity extends AppCompatActivity {

    List<String> name = new ArrayList<String>();
    List<int[]> startDate = new ArrayList<int[]>();
    List<int[]> endDate = new ArrayList<int[]>();
    List<Double> importance = new ArrayList<Double>();
    List<Boolean> repeat = new ArrayList<Boolean>();
    List<Long> repeatTime = new ArrayList<Long>();
    List<Boolean> completed = new ArrayList<Boolean>();
    List<Double> trueImportance = new ArrayList<Double>();
    LinearLayout checkBoxList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkBoxList = findViewById(R.id.checkbox_list);
        int[] testDate = {2019, 61, 43659};
        int[] testDate2 = {2019, 64, 50000};
        addListItem("1", testDate, testDate2, 0.5, true, 999999, false, getTrueImportance(testDate, testDate2, 0.5),
                name, startDate, endDate, importance, repeat, repeatTime, completed, trueImportance);
        addListItem("2", testDate2, testDate, 0.6, false, 9009, true, getTrueImportance(testDate, testDate2, 0.6),
                name, startDate, endDate, importance, repeat, repeatTime, completed, trueImportance);
        addListItem("3", testDate, testDate2, 0.5, true, 999999, false, 0.9,
                name, startDate, endDate, importance, repeat, repeatTime, completed, trueImportance);
        addListItem("4", testDate2, testDate, 0.6, false, 9009, true, 0.1,
                name, startDate, endDate, importance, repeat, repeatTime, completed, trueImportance);
        addListItem("5", testDate, testDate2, 0.5, true, 999999, false, 0.22,
                name, startDate, endDate, importance, repeat, repeatTime, completed, trueImportance);
        addListItem("6", testDate2, testDate, 0.6, false, 9009, true, 0.74,
                name, startDate, endDate, importance, repeat, repeatTime, completed, trueImportance);
        organiseList(name, startDate, endDate, importance, repeat, repeatTime, completed, trueImportance);
        generateList(name);
    }
    public void generateList(List<String> name){
        for (int i = 0; i < name.size(); i++) {
            CheckBox ch = new CheckBox(getApplicationContext());
            ch.setText(name.get(i));
            checkBoxList.addView(ch);
        }

    }
    public void addListItem(String a, int[] b, int[] c, double d, boolean e, long f, boolean g, double h,
                            List<String> name, List<int[]> startDate, List<int[]> endDate, List<Double> importance,
                            List<Boolean> repeat, List<Long> repeatTime, List<Boolean> completed, List<Double> trueImportance){
        name.add(a);
        startDate.add(b);
        endDate.add(c);
        importance.add(d);
        repeat.add(e);
        repeatTime.add(f);
        completed.add(g);
        trueImportance.add(h);
    }

    public void switchListItem(int i, int j, List<String> name, List<int[]> startDate, List<int[]> endDate, List<Double> importance,
                               List<Boolean> repeat, List<Long> repeatTime, List<Boolean> completed, List<Double> trueImportance){

        int[] startDateTemp = new int[3];
        int[] endDateTemp = new int[3];

        String nameTemp = name.get(i);
        startDateTemp = startDate.get(i);
        endDateTemp = endDate.get(i);
        double importanceTemp = importance.get(i);
        boolean repeatTemp = repeat.get(i);
        long repeatTimeTemp = repeatTime.get(i);
        boolean completedTemp = completed.get(i);
        double trueImportanceTemp = trueImportance.get(i);

        name.set(i, name.get(j));
        startDate.set(i, startDate.get(j));
        endDate.set(i, endDate.get(j));
        importance.set(i, importance.get(j));
        repeat.set(i, repeat.get(j));
        repeatTime.set(i, repeatTime.get(j));
        completed.set(i, completed.get(j));
        trueImportance.set(i, trueImportance.get(j));

        name.set(j, nameTemp);
        startDate.set(j, startDateTemp);
        endDate.set(j, endDateTemp);
        importance.set(j, importanceTemp);
        repeat.set(j, repeatTemp);
        repeatTime.set(j, repeatTimeTemp);
        completed.set(j, completedTemp);
        trueImportance.set(j, trueImportanceTemp);
    }

    public double getTrueImportance(int[] startDate, int[] endDate, double userImportance){

        long timeDifference = timeLeftInSeconds(startDate, endDate);

        double trueImportance = 1;

        trueImportance = userImportance * Math.pow(1.5, -(timeDifference/86400));

        return trueImportance;

    }
    public void organiseList(List<String> name, List<int[]> startDate, List<int[]> endDate, List<Double> importance,
                             List<Boolean> repeat, List<Long> repeatTime, List<Boolean> completed, List<Double> trueImportance){
        for (int i = 0; i < name.size(); i++){
            for (int j = i; j > 0; j--){
                if(trueImportance.get(j) < trueImportance.get(j-1)){
                    switchListItem(j, (j-1), name, startDate, endDate, importance, repeat, repeatTime, completed, trueImportance);
                }
            }
        }
    }
    public long dateToSeconds(int[] date){

        long secondSum = 0;

        secondSum += (date[0] - 2001)*365*24*60*60;
        secondSum += (date[1])*24*60*60;
        secondSum += date[2];

        return secondSum;

    }

    public int[] secondsToDate(long seconds){
        int[] date = new int[3];

        date[0] = (int) (seconds/(365*24*60*60) + 2001);
        date[1] = (int) (seconds - (date[0]-2001)*365*24*60*60)/(60*60*24);
        date[2] = (int) (seconds - (date[0]-2001)*365*24*60*60 - date[1]*24*60*60);

        return date;
    }

    public int[] timeLeftInDate(int[] date1, int[] date2){
        int[] dateLeft = new int[3];

        long secondsLeft = dateToSeconds(date2) - dateToSeconds(date1);
        dateLeft = secondsToDate(secondsLeft);
        dateLeft[0] -= 2001;

        return dateLeft;
    }

    public long timeLeftInSeconds(int[] date1, int[] date2){
        long secondsLeft = 0;

        secondsLeft = dateToSeconds(date2) - dateToSeconds(date1);

        return secondsLeft;
    }
}